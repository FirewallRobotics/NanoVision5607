// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

#include "NetworkListener.h"

using namespace cs;

class NetworkListener::Impl {};

NetworkListener::NetworkListener(wpi::Logger& logger, Notifier& notifier) {}

NetworkListener::~NetworkListener() = default;

void NetworkListener::Start() {}

void NetworkListener::Stop() {}
