if __name__ == "__main__":
    from .installer import main

    main()
