if __name__ == "__main__":
    from .netconsole import main

    main()
